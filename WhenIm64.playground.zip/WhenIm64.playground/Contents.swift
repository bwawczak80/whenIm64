import UIKit


import UIKit

class SixtyFourthYear {
    var yearOfBirth: Int
    var currentYear: Int
    let targetAge: Int
    
    init() {
        yearOfBirth = 0
        currentYear = 0
        targetAge = 64
    }
    
    func calculateYears() -> Int{
        let difference = targetAge - (currentYear - yearOfBirth)
        let yearOf64 = currentYear + difference
        return yearOf64
    }
}

let myYear = SixtyFourthYear()
myYear.yearOfBirth = 1980
myYear.currentYear = 2019

myYear.calculateYears()
